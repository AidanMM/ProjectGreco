﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RandomTerrainGeneration.Algorithms;

namespace RandomTerrainGeneration
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.SetWindowSize(LevelVariables.WIDTH + 1, LevelVariables.HEIGHT + 1);

            char[][] myLevel = new char[1][];

            Map myMap = new Map(AlgorithmType.HillsDesert, -1);

            Spawner mySpawner = new Spawner(myMap.Terrain, -1);

            myLevel = myMap.Terrain;



            for (int y = LevelVariables.HEIGHT - 1; y >= 0; y--)
            {
                for (int x = 0; x < LevelVariables.WIDTH; x++)
                {
                    Console.Write(myLevel[x][y]);
                }
                Console.WriteLine();
            }

            foreach(TemporaryEnemy myEnemy in mySpawner.EnemyData)
            {
                char enemyChar = 'P';
                switch(myEnemy.movementType)
                {
                    case EnemyType.Flying:
                        enemyChar = 'F';
                        break;
                    case EnemyType.Ghost:
                        enemyChar = 'H';
                        break;
                    case EnemyType.Ground:
                        enemyChar = 'G';
                        break;
                }

                switch(myEnemy.size)
                {
                    case EnemySize.Large:
                        Console.SetCursorPosition(myEnemy.xPosition, LevelVariables.HEIGHT - myEnemy.yPosition);
                        Console.Write(enemyChar);
                        Console.SetCursorPosition(myEnemy.xPosition + 1, LevelVariables.HEIGHT - myEnemy.yPosition);
                        Console.Write(enemyChar);
                        Console.SetCursorPosition(myEnemy.xPosition, LevelVariables.HEIGHT - myEnemy.yPosition + 1);
                        Console.Write(enemyChar);
                        Console.SetCursorPosition(myEnemy.xPosition + 1, LevelVariables.HEIGHT - myEnemy.yPosition + 1);
                        Console.Write(enemyChar);
                        break;
                    case EnemySize.Medium:
                        Console.SetCursorPosition(myEnemy.xPosition, LevelVariables.HEIGHT - myEnemy.yPosition);
                        Console.Write(enemyChar);
                        break;
                    case EnemySize.Small:
                        Console.SetCursorPosition(myEnemy.xPosition, LevelVariables.HEIGHT - myEnemy.yPosition);
                        Console.Write(enemyChar);
                        break;

                }
            }

            Console.SetCursorPosition(0, LevelVariables.HEIGHT);
        }
    }
}
